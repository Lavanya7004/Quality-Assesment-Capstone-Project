# Overview

TEXT_ASSESS80 is an AI-based web application designed to evaluate and analyze written text for quality, grammar, and clarity.
The system processes input text and provides feedback or enhancement suggestions, making it useful for students, educators, and professionals who want to assess writing quality quickly and effectively.

This project aims to combine natural language processing techniques with an easy-to-use web interface for real-time text evaluation.

## How to Run the Project Locally

Step 1 — Prerequisites

Make sure you have the following installed:

Node.js (v18 or higher)

npm or yarn

## Setup Instructions

# 1. Clone this repository

git clone <your_repo_link>

# 2. Navigate into the project folder

cd TEXT_ASSESS80

# 3. Install dependencies

npm install

# 4. Run the development server

npm run dev
View in Browser

Once the server starts, open your browser and go to:
http://localhost:5173
